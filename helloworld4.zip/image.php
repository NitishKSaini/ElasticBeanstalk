<!DOCTYPE html>
<html>
<body>

<h1>Image</h1>

<img src="aws-icon.png" />

</body>
</html>
